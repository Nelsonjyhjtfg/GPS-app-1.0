package com.nelson.gps

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

// Please make sure to add the following permissions in your AndroidManifest.xml:
// <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
// <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

class MainActivity : AppCompatActivity() {

    // UI elements
    private lateinit var tvStatus: TextView
    private lateinit var tvLatitude: TextView
    private lateinit var tvLongitude: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvSatellites: TextView
    private lateinit var tvTimeZones: TextView
    private lateinit var tvCurrentTimeZone: TextView
    private lateinit var tvCurrentSpeed: TextView
    private lateinit var tvDistance: TextView
    private lateinit var tvTripStatus: TextView

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnRecordTrip: Button
    private lateinit var btnEndTrip: Button
    private lateinit var debugModeSwitch: Switch
    private lateinit var tvDebugLog: TextView

    private lateinit var mainScrollView: ScrollView
    private lateinit var mainCardView: CardView
    private lateinit var tripCardView: CardView
    private lateinit var coordsCardView: CardView
    private lateinit var tvCurrentSpeedLabel: TextView
    private lateinit var tvSatellitesLabel: TextView
    private lateinit var tvDistanceLabel: TextView

    // Location and GPS managers
    private lateinit var locationManager: LocationManager
    private val LOCATION_PERMISSION_REQUEST_CODE = 101

    // State variables
    private var isRecordingTrip = false
    private var totalDistance = 0f
    private var lastLocation: Location? = null

    // UI Colors (fixed to dark mode)
    private val darkBackgroundColor = "#212121"
    private val darkCardColor = "#323232"
    private val darkTextColor = "#FFFFFF"
    private val darkHintTextColor = "#BDBDBD"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Binding UI elements from XML
        tvStatus = findViewById(R.id.tvStatus)
        tvLatitude = findViewById(R.id.tvLatitude)
        tvLongitude = findViewById(R.id.tvLongitude)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvSatellites = findViewById(R.id.tvSatellites)
        tvTimeZones = findViewById(R.id.tvTimeZones)
        tvCurrentTimeZone = findViewById(R.id.tvCurrentTimeZone)
        tvCurrentSpeed = findViewById(R.id.tvCurrentSpeed)
        tvDistance = findViewById(R.id.tvDistance)
        tvTripStatus = findViewById(R.id.tvTripStatus)

        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnRecordTrip = findViewById(R.id.btnRecordTrip)
        btnEndTrip = findViewById(R.id.btnEndTrip)
        debugModeSwitch = findViewById(R.id.debugModeSwitch)
        tvDebugLog = findViewById(R.id.tvDebugLog)

        mainScrollView = findViewById(R.id.main_scroll_view)
        mainCardView = findViewById(R.id.mainCardView)
        tripCardView = findViewById(R.id.tripCardView)
        coordsCardView = findViewById(R.id.coordsCardView)
        tvCurrentSpeedLabel = findViewById(R.id.textView_current_speed_label)
        tvSatellitesLabel = findViewById(R.id.textView_satellites_label)
        tvDistanceLabel = findViewById(R.id.textView_distance_label)

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        // Initial UI setup (fixed dark theme and English strings)
        setDarkTheme()

        btnStart.setOnClickListener {
            if (checkLocationPermission()) {
                startGpsUpdates()
            } else {
                requestLocationPermission()
            }
        }

        btnStop.setOnClickListener {
            stopGpsUpdates()
        }

        btnRecordTrip.setOnClickListener {
            isRecordingTrip = true
            totalDistance = 0f
            lastLocation = null
            tvTripStatus.text = "Trip Status: Recording"
            appendLog("Trip recording started.")
        }

        btnEndTrip.setOnClickListener {
            isRecordingTrip = false
            tvTripStatus.text = "Trip Status: Idle"
            appendLog("Trip recording stopped. Total distance: %.2f km".format(totalDistance / 1000))
        }

        debugModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            tvDebugLog.visibility = if (isChecked) View.VISIBLE else View.GONE
            debugModeSwitch.text = if (isChecked) "User Mode" else "Debug Mode"
            appendLog("Debug mode is now ${if (isChecked) "ON" else "OFF"}")
        }
    }

    private fun appendLog(message: String) {
        val currentTime = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(Date())
        tvDebugLog.append("\n[$currentTime] $message")

    }

    private fun setDarkTheme() {
        mainScrollView.setBackgroundColor(android.graphics.Color.parseColor(darkBackgroundColor))
        mainCardView.setCardBackgroundColor(android.graphics.Color.parseColor(darkCardColor))
        tripCardView.setCardBackgroundColor(android.graphics.Color.parseColor(darkCardColor))
        coordsCardView.setCardBackgroundColor(android.graphics.Color.parseColor(darkCardColor))

        tvStatus.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvCurrentSpeed.setTextColor(android.graphics.Color.parseColor("#4CAF50"))
        tvDistance.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvTripStatus.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvLatitude.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvLongitude.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvSpeed.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvSatellites.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvCurrentTimeZone.setTextColor(android.graphics.Color.parseColor(darkTextColor))
        tvTimeZones.setTextColor(android.graphics.Color.parseColor(darkHintTextColor))
        tvCurrentSpeedLabel.setTextColor(android.graphics.Color.parseColor(darkHintTextColor))
        tvSatellitesLabel.setTextColor(android.graphics.Color.parseColor(darkHintTextColor))
        tvDistanceLabel.setTextColor(android.graphics.Color.parseColor(darkHintTextColor))
    }

    private fun checkLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                startGpsUpdates()
                appendLog("Location permission granted. Starting GPS updates.")
            } else {
                tvStatus.text = "GPS Status: Permission Denied"
                appendLog("Location permission denied. GPS updates will not start.")
            }
        }
    }

    private fun startGpsUpdates() {
        try {
            tvStatus.text = "GPS Status: Waiting for data..."
            appendLog("Starting GPS updates.")

            // Request location updates
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000, // minTime (ms)
                1f,   // minDistance (meters)
                locationListener
            )

            // Register GnssStatus callback for satellite count
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                locationManager.registerGnssStatusCallback(gnssStatusCallback, null)
                appendLog("Registered GnssStatusCallback.")
            } else {
                tvSatellites.text = "Satellites: Requires API Level 24+ to show satellite count"
                appendLog("GnssStatusCallback is not supported on this device.")
            }

        } catch (e: SecurityException) {
            tvStatus.text = "GPS Status: Security Exception"
            appendLog("ERROR: Security Exception. Check Manifest and runtime permissions.")
        } catch (e: Exception) {
            tvStatus.text = "GPS Status: An unexpected error occurred"
            appendLog("ERROR: An unexpected error occurred: ${e.message}")
        }
    }

    private fun stopGpsUpdates() {
        try {
            locationManager.removeUpdates(locationListener)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                locationManager.unregisterGnssStatusCallback(gnssStatusCallback)
            }
            tvStatus.text = "GPS Status: Stopped"
            appendLog("GPS updates stopped.")
            // Clear all data display
            tvLatitude.text = "Latitude:"
            tvLongitude.text = "Longitude:"
            tvSpeed.text = "Speed:"
            tvSatellites.text = "Satellites:"
            tvCurrentSpeed.text = "0.00 km/h"
            tvCurrentTimeZone.text = "Current Time Zone:"
            tvTimeZones.text = "World Time Zones:"
        } catch (e: SecurityException) {
            tvStatus.text = "GPS Status: Security Exception"
            appendLog("ERROR: Security Exception while stopping GPS.")
        } catch (e: Exception) {
            tvStatus.text = "GPS Status: An unexpected error occurred"
            appendLog("ERROR: An unexpected error occurred while stopping GPS: ${e.message}")
        }
    }

    private val locationListener: LocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            tvStatus.text = "GPS Status: GPS Active"
            updateLocationUI(location)

            // Distance calculation
            if (isRecordingTrip) {
                if (lastLocation != null) {
                    totalDistance += lastLocation!!.distanceTo(location)
                }
                lastLocation = location
                val distanceUnit = "km"
                tvDistance.text = String.format(Locale.ENGLISH, "%.2f %s", totalDistance / 1000, distanceUnit)
            }
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            appendLog("Provider status changed for $provider: $status")
        }
        override fun onProviderEnabled(provider: String) {
            tvStatus.text = "GPS Status: GPS provider enabled"
            appendLog("GPS provider enabled: $provider")
        }
        override fun onProviderDisabled(provider: String) {
            tvStatus.text = "GPS Status: GPS provider disabled"
            appendLog("GPS provider disabled: $provider")
        }
    }

    private val gnssStatusCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var satelliteCount = 0
            var usedInFixCount = 0
            for (i in 0 until status.satelliteCount) {
                satelliteCount++
                if (status.usedInFix(i)) {
                    usedInFixCount++
                }
            }
            tvSatellites.text = "$usedInFixCount / $satelliteCount"
            appendLog("Satellite status changed. Used in fix: $usedInFixCount, Total: $satelliteCount")
        }
    }

    private fun updateLocationUI(location: Location) {
        tvLatitude.text = String.format(Locale.ENGLISH, "Latitude: %.6f", location.latitude)
        tvLongitude.text = String.format(Locale.ENGLISH, "Longitude: %.6f", location.longitude)

        if (location.hasSpeed()) {
            val speed = location.speed * 3.6f
            val unit = "km/h"
            tvSpeed.text = String.format(Locale.ENGLISH, "Speed: %.2f %s", speed, unit)
            tvCurrentSpeed.text = String.format(Locale.ENGLISH, "%.2f %s", speed, unit)
        } else {
            val unit = "km/h"
            tvSpeed.text = "Speed: Unknown"
            tvCurrentSpeed.text = "0.00 $unit"
        }

        val utcDate = Date(location.time)
        val utcFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)
        utcFormat.timeZone = TimeZone.getTimeZone("UTC")
        val utcTimeStr = utcFormat.format(utcDate)

        val gmtOffsetHours = (location.longitude / 15.0).toInt()
        val gmtOffsetString = if (gmtOffsetHours >= 0) "+$gmtOffsetHours" else gmtOffsetHours.toString()
        val estimatedTimeZone = "GMT$gmtOffsetString"
        tvCurrentTimeZone.text = String.format(Locale.ENGLISH, "Current Time Zone: %s", estimatedTimeZone)

        val timeZonesBuilder = StringBuilder("World Time Zones:\n")
        val offsetFormat = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH)

        for (offset in -12..12) {
            val tz = "GMT%s%d".format(if (offset >= 0) "+" else "", offset)
            offsetFormat.timeZone = TimeZone.getTimeZone(tz)
            val timeStr = offsetFormat.format(utcDate)
            timeZonesBuilder.append("  ${tz}: $timeStr\n")
        }
        tvTimeZones.text = timeZonesBuilder.toString()
    }
}
